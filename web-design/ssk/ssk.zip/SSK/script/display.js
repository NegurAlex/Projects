function show(id)
{
hideshow = document.getElementById(id);
if (hideshow.style.display == 'none')
{
	hideshow.style.display = '';
	} else {
	window.clearTimeout(timeoutID);
	}
}
function hide(id)
{
timeoutID=setTimeout("hideshow.style.display = 'none'", 1); //Set delay
}
function stopTimer() {
window.clearTimeout(timeoutID);
}