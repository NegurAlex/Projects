var TIMER = null;
var DROP_STEP = 30;
var CUR_DROP_HEIGHT;
var CONTENT_HEIGHT;

var MainDiv, DropMenu, DropMenuContent

function Init(objDiv)
{
    if (TIMER == null)
    {
        MainDiv = objDiv.parentNode;
        
        DropMenu = MainDiv.getElementsByTagName("DIV").item(1)
        DropMenuContent = DropMenu.getElementsByTagName("DIV").item(0);

		CONTENT_HEIGHT=parseInt(DropMenuContent.style.height);

		if (DropMenuContent.getAttribute("state") == 0)
			CUR_DROP_HEIGHT = 0; 
		else
			CUR_DROP_HEIGHT = CONTENT_HEIGHT; 
    }

}

function Dropper()
{
    if (DropMenuContent.getAttribute("state") == 0)
    {
        CUR_DROP_HEIGHT += DROP_STEP;
        DropMenu.style.height = CUR_DROP_HEIGHT;

        if (CUR_DROP_HEIGHT >= CONTENT_HEIGHT)
        {
            clearInterval(TIMER);
            TIMER = null;
            DropMenuContent.style.display = 'inline';
            DropMenuContent.setAttribute("state","1")
        }
		
    } else
    {
        CUR_DROP_HEIGHT -= DROP_STEP;
		DropMenuContent.style.display = 'none';
        
        if(CUR_DROP_HEIGHT > 0)
			DropMenu.style.height = CUR_DROP_HEIGHT;
        else
        {
            clearInterval(TIMER);
            TIMER = null;

			CUR_DROP_HEIGHT = 0;
            DropMenu.style.height = CUR_DROP_HEIGHT
            DropMenuContent.setAttribute("state","0")
        }
		
    }
}