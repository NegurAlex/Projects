////ADS

function showAds(){
    var pageNum = $.cookie('adsShowedN');
    var pageTime = $.cookie('adsShowedT');
    var pDate = dateTryParse(pageTime);
    var cDate = new Date();
        cDate.setDate(cDate.getDate()-5);

    //alert('page number = '+pageNum)
    //alert('page time = '+pageTime)

    if(pDate.isDate){
        //alert('cookie time = '+pDate.date)
        //alert('current time = '+cDate)
        if(cDate>pDate.date){
            //alert('date expired')
            pageNum = null;
        }
    }
    else{
        pageNum = null;
    }   

    if( (pageNum==null || pageNum=='') ){
        //alert('first page visited')
        SaveCookie('adsShowedN','1');
        $.cookie('adsShowedN','1')
        var d = new Date();
        ds = d.getFullYear()+'.'+d.getMonth()+'.'+d.getDate()+'.'+d.getHours()+'.'+d.getMinutes();
        SaveCookie('adsShowedT',ds);
        $.cookie('adsShowedT',ds)
    } else if($.cookie('adsShowedN')=='1'){
        //alert('show ads page visited')
        $id('adsDiv').style.display = '';
        $id('divBody').style.display = 'none';
        setTimeout('hideAds()',5000);
        SaveCookie('adsShowedN','2');
        $.cookie('adsShowedN','2')
        var d = new Date();
        ds = d.getFullYear()+'.'+d.getMonth()+'.'+d.getDate()+'.'+d.getHours()+'.'+d.getMinutes();
        SaveCookie('adsShowedT',ds);
        $.cookie('adsShowedT',ds)
    } 
    //else alert('ads was shown')
    
}
function dateTryParse(dText){
    if(dText==null || dText=='')
        return { isDate: false, date: null };
    try{
        var arr = dText.split('.');
        dDate = new Date()
        dDate.setFullYear(arr[0])
        dDate.setMonth(eval(arr[1]))
        dDate.setDate(arr[2])
        dDate.setHours(arr[3])
        dDate.setMinutes(arr[4])
        return { isDate: true, date: dDate };
    }
    catch(e){
        return { isDate: false, date: null };
    }
}
function hideAds(){
    $id('adsDiv').style.display = 'none';
    $id('divBody').style.display = '';
}

//// end ADS

function clickdayinfo(e){
	OpenWindowOverMainItem(e,'/_site/src/inc/dayinfo.aspx',627, 366);
	return false;
}

function OpenWindowOverMainItem(e,url,width,height){
    var posDivStart = $("#mainItemStart").position();
    var x,sx,px;
    if (!e) { e = window.event; }
    var el = (typeof (e.target) != "undefined") ? e.target : e.srcElement;
    if(document.all){
        px = event.clientX;
        sx = event.screenX;
    } else {
        px = e.pageX;
        sx = e.screenX;
    }
    var pos = $(el).position();
    x = sx - (px-(pos.left-$(document).scrollLeft()/2) ) + (posDivStart.left - pos.left);
    x = x<0?0:x;
    newWindow(url, 'popup', width,height, 1, 0, 0, 0, 0, 1, 0, x,null);return false;
}

function newWindow(a_str_windowURL, a_str_windowName, a_int_windowWidth, a_int_windowHeight, a_bool_scrollbars, a_bool_resizable, a_bool_menubar, a_bool_toolbar, a_bool_addressbar, a_bool_statusbar, a_bool_fullscreen,left,top) {
  var int_windowLeft = (left==null)?(screen.width - a_int_windowWidth) / 2:left;
  var int_windowTop = (top==null)?(screen.height - a_int_windowHeight) / 2:top;
  var str_windowProperties = 'height=' + a_int_windowHeight + ',width=' + a_int_windowWidth + ',top=' + int_windowTop + ',left=' + int_windowLeft + ',scrollbars=' + a_bool_scrollbars + ',resizable=no,menubar=' + a_bool_menubar + ',toolbar=' + a_bool_toolbar + ',location=' + a_bool_addressbar + ',statusbar=' + a_bool_statusbar + ',fullscreen=' + a_bool_fullscreen + '';
  var obj_window = window.open(a_str_windowURL, a_str_windowName, str_windowProperties)
    if (parseInt(navigator.appVersion) >= 4) {
      obj_window.window.focus();
    }
}

// Smart News
var leftBlockArray = new Array('Foto','Video','Popular');

function clickSNSave(e){
    e.style.display = 'none';
    e.parentNode.getElementsByTagName('div')[1].style.display = '';
    SaveCookie("SNTab",currentLeftBlockTab);
    return false;
}
function clickSNRestore(e){
    e.style.display = 'none';
    e.parentNode.getElementsByTagName('div')[0].style.display = '';
    RemoveCookie("SNTab");
    NowBlockClick(0);
    return false;
}

function NowBlockClick(n){
    $id("leftLink"+leftBlockArray[currentLeftBlockTab]).className = "UnRegularBlockTab";
    $id("leftLink"+leftBlockArray[n]).className = "UnRegularBlockTab_active";
    $id("leftDiv"+leftBlockArray[currentLeftBlockTab]).style.display = 'none';
    $id("leftDiv"+leftBlockArray[n]).style.display = '';
    $id("leftBlockDivDescr"+leftBlockArray[currentLeftBlockTab]).style.display = 'none';
    $id("leftBlockDivDescr"+leftBlockArray[n]).style.display = '';
    currentLeftBlockTab = n;
    return false
}

var currentLeftBlockTab = getCookieSesion('SNTab',0)
var savedLeftBlockTab = isSavedCookie('SNTab');

function lbImgFuncNew(n,e){e.src = n}

function lbImgFunc(n,e){e.getElementsByTagName("img")[0].src = n}

var ajaxForSmartBlock = '/_site/src/inc/ajax/nowBlockAJAX.aspx'
function leftBlockClick(n,count,e,index){
    var cur = eval(e.parentNode.parentNode.getElementsByTagName("td")[0].id);
    cur+=n;
    if(0>cur||cur>2) return false;
    e.parentNode.parentNode.getElementsByTagName("td")[0].id = cur;
    e.parentNode.parentNode.getElementsByTagName("td")[0].innerHTML = (cur+1)+" �� 3"
    eval("$.get(ajaxForSmartBlock+'?tab='+currentLeftBlockTab+'&i=' +(cur*count),null, function(data){getSNdataAJAX(data,'"+index+"')})");
    return false;
}
function getSNdataAJAX(data, i){
    $id("leftDiv"+leftBlockArray[i]).innerHTML = data
}
function selectSN(e,n){
  $("#snSelectorTR .page3act").attr("class","page3");
  $(e).attr("class","page3act");
  
  var links = $("#editorSelection .i1");
  for(var i=0;i<n;i++) $(links[i]).css("display","")
  for(var i=n;i<links.length;i++) $(links[i]).css("display","none")
  $.cookie("SNC",n)
}



// Tab paging
  function getCookieSesion(name,def){
    var val = $.cookie(name);
      if(val==null||val=='')
          val = def;
      var filter = /^\d*$/i
      if(!filter.test(val))
          val = def;
      return eval(val)
  }
  function select(e,n,name,cook){
      $("#"+name+" .page3act").attr("class","page3");
      $(e).attr("class","page3act");
      var links = $("#"+name+" .addLink4");
      for(var i=0;i<n;i++) $(links[i]).css("display","")
      for(var i=n;i<links.length;i++) $(links[i]).css("display","none")
      $.cookie(cook,n)
  }

function isSavedCookie(name){
   return !($.cookie(name)=='' || $.cookie(name)==null)
}
// Tabs

 function showTabNew(arr,n,index){
    $id(arr[eval(n)][0]).className = "UnRegularBlockTabArticle";
    $id(arr[eval(n)][1]).style.display = 'none';
    eval(n + "= eval(index);");
    $id(arr[index][0]).className = "UnRegularBlockTabArticle_active";
    $id(arr[index][1]).style.display = '';
} 
function clickCookieRestoreNew(e,n,arr,vrn){
    e.style.display = 'none';
    e.parentNode.getElementsByTagName('a')[0].style.display = '';
    RemoveCookie(n);
    showTabNew(arr,vrn,0)
}

function showTab(arr,n,index){
    $id(arr[eval(n)][0]).className = "tabPassive";
    $id(arr[eval(n)][0]).innerHTML = "<div class='tabPassiveIn'><a style='cursor:hand;'>"+$id(arr[eval(n)][0]).innerHTML+"</a></div>";
    $id(arr[eval(n)][1]).style.display = 'none';
    eval(n + "= eval(index);");
    $id(arr[index][0]).className = "tabActive";
    $id(arr[index][0]).innerHTML = $id(arr[index][0]).firstChild.firstChild.innerHTML;
    $id(arr[index][1]).style.display = '';
}
function clickCookieSave(e,n,v){
    e.style.display = 'none';
    e.parentNode.getElementsByTagName('a')[1].style.display = '';
    SaveCookie(n, eval(v));
}
function clickCookieRestore(e,n,arr,vrn){
    e.style.display = 'none';
    e.parentNode.getElementsByTagName('a')[0].style.display = '';
    RemoveCookie(n);
    showTab(arr,vrn,0)
}

function MM_swapImageNew(e) {
    e.getElementsByTagName('img')[0].src = "/_site/_pic/sn/pin_hover_b.gif"
}
function MM_swapImgRestoreNew(e) {
    e.getElementsByTagName('img')[0].src = "/_site/_pic/sn/pin_regular_b.gif"
}
function MM_swapImage(e) {
    e.getElementsByTagName('img')[0].src = "/_site/_pic/sn/pin_hover.gif"
}
function MM_swapImgRestore(e) {
    e.getElementsByTagName('img')[0].src = "/_site/_pic/sn/pin_regular.gif"
}


function SaveCookie(n,v,time){
    if(time==null)
        $.get("/_site/src/inc/cookie.ashx?n="+n+"&v="+v,null,reciveData);
    else
        $.get("/_site/src/inc/cookie.ashx?n="+n+"&v="+v+"&t="+time,null,reciveData);
}
function RemoveCookie(n){
    $.get("/_site/src/inc/cookie.ashx?mode=remove&n="+n,null,reciveData);
}
function reciveData(data){
}

        // Slide
        function PassiveTab(t){
            $id("tab"+t).style.display = "none";
            $id("btn"+t).className = "butPassive";
            $id("img"+t).style.display = "none";
        }
        
        function ActiveTab(t){
            $id("tab"+t).style.display = "";
            $id("btn"+t).className = "butActive";
            $id("img"+t).style.display = "";
        }

        function HideShownTab(){ 
            if ( $id("tabWebConf").style.display != "none" ) PassiveTab("WebConf"); 
            else if ( $id("tabFoto").style.display != "none" ) PassiveTab("Foto"); 
            else PassiveTab("Video"); 
        }
        
        function showWebConf(){ HideShownTab(); ActiveTab("WebConf") }
        function showFoto(){ HideShownTab(); ActiveTab("Foto") }
        function showVideo(){ HideShownTab(); ActiveTab("Video") } 
    
        // Clock
        var m_names = new Array("������","�������","�����","������","���","����","����","�������","��������","�������","������","�������");
        var serverDateTime;
        function showInitCD(){
            $.get("/_site/src/inc/ajax/serverTime.ashx",null,finishShowInitCD);
        }
        function finishShowInitCD(data){
            eval("var serverDate =" + data);
            serverDateTime = new Date();
            serverDateTime.setFullYear(serverDate[0],serverDate[1]-1,serverDate[2]);
            serverDateTime.setHours(serverDate[3],serverDate[4],serverDate[5]);
            showCD();
        }

    var daysOfWeek = new Array("�����������","�����������","�������","�����","�������","�������","�������");


        function showCD(){
            serverDateTime.setSeconds(serverDateTime.getSeconds()+1);
            var d = serverDateTime;
            var cd = d.getDate();   var cmth = d.getMonth();    var ch=d.getHours();var cm=d.getMinutes();
            if (ch==0) ch=12;   if (cm<=9) cm="0"+cm;

        //document.getElementById("curDate").innerHTML = daysOfWeek[d.getDay()]+" "+ch+":"+cm + "<br/>"+cd+" "+m_names[cmth]

        document.getElementById("curDate").innerHTML = daysOfWeek[d.getDay()]+" <br/>"+cd+" "+m_names[cmth]+" "+ch+":"+cm
            setTimeout("showCD()",1000)
        }
    
        // Image
        function $id(id) {return document.getElementById(id)}
        function showImg(pos) {
            curImg+=pos;
            $id("imgID").src = aImages[curImg][0];
            $id("imgDesc").innerHTML = aImages[curImg][1];
            $id("imgPos").innerHTML = curImg+1;
            
            if(curImg==0) $id("imgPrev").style.visibility = "hidden"; else $id("imgPrev").style.visibility = ""
            if(curImg==aImages.length-1) $id("imgNext").style.visibility = "hidden"; else $id("imgNext").style.visibility = ""
        }
        var curImg = 0;
    
    
        // Horoscop
        function horShow() {
            $.get("/_site/src/inc/horoscop.ashx?sv="+$id("selectHor").value,null,horLoad);
        }
        function horLoad(data) {
            $id("horText").innerHTML = data;
        }
    
        //  tabs
        function showDivInd() {
            if (!$("#tab1").is(":hidden")) return 1;
            else if (!$("#tab2").is(":hidden")) return 2;
            else return 3;
        }
        
        function showTab1(){ if ($("#tab1").is(":hidden")) { $("#tab"+showDivInd()).hide();showTD1(); } }

        function showTD1(){ $("#tab1").show(); }

        function showTab2(){ if ($("#tab2").is(":hidden")) { $("#tab"+showDivInd()).hide();showTD2(); } }

        function showTD2(){ $("#tab2").show(); }

        function showTab3(){ if ($("#tab3").is(":hidden")) { $("#tab"+showDivInd()).hide();showTD3(); } }

        function showTD3(){ $("#tab3").show(); }

        // tabs2
        function showDivNewInd() {
            if (!$("#tabNew1").is(":hidden")) return 1;
            else if (!$("#tabNew2").is(":hidden")) return 2;
            else if (!$("#tabNew3").is(":hidden")) return 3;
            else if (!$("#tabNew4").is(":hidden")) return 4;
            else return 5;
        }
        
        function showTabNew1(){ if ($("#tabNew1").is(":hidden")) { $("#tabNew"+showDivNewInd()).hide();showTDNew1(); } }

        function showTDNew1(){ $("#tabNew1").show(); }

        function showTabNew2(){ if ($("#tabNew2").is(":hidden")) { $("#tabNew"+showDivNewInd()).hide();showTDNew2(); } }

        function showTDNew2(){ $("#tabNew2").show(); }

        function showTabNew3(){ if ($("#tabNew3").is(":hidden")) { $("#tabNew"+showDivNewInd()).hide();showTDNew3(); } }

        function showTDNew3(){ $("#tabNew3").show(); }

        function showTabNew4(){ if ($("#tabNew4").is(":hidden")) { $("#tabNew"+showDivNewInd()).hide();showTDNew4(); } }

        function showTDNew4(){ $("#tabNew4").show(); }

        function showTabNew5(){ if ($("#tabNew5").is(":hidden")) { $("#tabNew"+showDivNewInd()).hide();showTDNew5(); } }

        function showTDNew5(){ $("#tabNew5").show(); }


    function print_day()
    {
    //13 �������, �������
    var d=new Date()
    var weekday=new Array("�����������", "�����������", "�������", "�����", "�������", "�������", "�������")
    var monthname=new Array("������","�������","�����","������","���","����","����","�������","��������","�������","������","�������")
    document.write(d.getDate() + " ")
    document.write(monthname[d.getMonth()] + ", ")
    document.write(weekday[d.getDay()])
    }
    
      function MM_jumpMenu(targ,selObj,restore){ //v3.0
      eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
      if (restore) selObj.selectedIndex=0;      
    }
    
    
    function $id(id) {return document.getElementById(id)}
    //-->
    
 
// toggles the slickbox on clicking the noted link      
/*$(document).ready(function() {

  $('#converter').hide();    

  $('a#show_converter').click(function() {    
    $('#converter').toggle(400);    
    $id('show_converter').innerHTML= $id('converter').offsetHeight>10?'������� ��������� �����':'������� ��������� �����';
    return false;
  });
  
}); */
function convertorClickOpen(){
    $('#converter').toggle(400);    
    $id('show_converter').innerHTML= $id('converter').offsetHeight>10?'������� ��������� �����':'������� ��������� �����';
}


//topmenu
    function openHideAllProj(e){
        if ($("#listProjects").is(":hidden")) { 
            $("#listProjects").slideDown(1000);
            e.className = "fullOpen";
        }
        else {
            $("#listProjects").slideUp(1000); 
            e.className = "fullAllProjects";
        }
    }

//presentation
    function openHidePres(e){
        if ($("#listPress").is(":hidden")) { 
            $("#listPress").slideDown(200);

            e.innerHTML = "<b>������� ��� �� �����</b>"
        }
        else {
            $("#listPress").slideUp(200); 

            e.innerHTML = "<b>�������� ��� �� �����</b>"
        }
    }

// ***********************
// Weather
// ***********************

    var cityWSearchURL = "/_site/src/inc/cityWSearch.ashx";
    var weatherURL = "/_site/src/inc/weather.ashx";
    var regionNewsURL = "/_site/src/inc/ajax/regionNewsAJAX.aspx";
    var weatherSectionURL = "http://obozrevatel.com/_site/src/weather.aspx";
    var regionSectionURL = "/list_noimg/geography_";
    var kiyanyURL = 'http://kiyany.obozrevatel.com/';
    var curRCity = 0;
    var curWCity = 0;

    var savedW = ($.cookie('Oboz/Weather')!=null) && ($.cookie('Oboz/Weather')!='');
    var savedR = ($.cookie('Oboz/Region')!=null) && ($.cookie('Oboz/Region')!='');

//$(document).ready(pageLoadShowWeather);
// Weather  
function changeCity(e){
    if(e.innerHTML == "�������") {
        e.innerHTML = "��������"
        $("#countryWSearch").slideUp();
    }
    else {
        e.innerHTML = "�������"
        $("#countryWSearch").slideDown();
    }
}
function findWCountry(){
    $.get(cityWSearchURL+"?text="+escape($id("countryWText").value),null,foundWCountry);
    $("#countryWResult").slideUp("slow");
}
var tmpWCountry;
function foundWCountry(data){
    tmpWCountry = data;
    showFoundWCountry();
}
function showFoundWCountry(){
    if ($("#countryWResult").is(":hidden")) {
        $id("countryWResult").innerHTML = tmpWCountry;
        $("#countryWResult").slideDown("slow");
    }
    else {
        setTimeout("showFoundWCountry()",0);
    }
}
function selectWCountry(id,e){
    $("#countryWResult").slideUp("slow");
    selectWCityName(id,e.innerHTML);
}
function selectWCityName(id,name){
    curWCity = id;
    $id("hrefCountryW").innerHTML = "<strong>"+name+"</strong>";
    $id("hrefCountryW").href = weatherSectionURL + "?city_name_ru="+name;
    $("#weather").fadeOut("slow");
    $.get(weatherURL+"?id="+id,null,getWeather);
}
var tmpWData;
function getWeather(data){
    tmpWData = data;
    gotWData();
}
function gotWData(){
    if ($("#weather").is(":hidden")) {
        $id("weather").innerHTML = tmpWData;
        $("#weather").fadeIn("slow");
    }
    else {
        setTimeout("gotWData()",0);
    }
}


// Region
function findMyRegionCity(){
    $.get(cityWSearchURL+"?mode=news&text="+escape($id("textMyRegion").value),null,foundMyRegionCity);
    $("#myRegionResult").slideUp("slow");
}
var tmpMyRegion;
function foundMyRegionCity(data){
    tmpMyRegion = data;
    showFoundMyRegionCity();
}
function showFoundMyRegionCity(){
    if ($("#myRegionResult").is(":hidden")) {
        $id("myRegionResult").innerHTML = tmpMyRegion;
        $("#myRegionResult").slideDown("slow");
    }
    else {
        setTimeout("showFoundMyRegionCity()",0);
    }
}
function selectMyRegionCity(id,e){
    selectRCityName(id, e.innerHTML);
}
function selectRCityName(id, name){
    curRCity = id;
    $("#myRegionResult").slideUp("slow");
    $id('linkMyRegion').innerHTML = "<strong>" + name + "</strong>";
    
    if(eval(id)==207)
        $id('linkMyRegion').href = kiyanyURL;
    else
        $id('linkMyRegion').href = regionSectionURL + id + ".htm";
    $.get(regionNewsURL+"?cid="+id,regionNewsLoad);
}
function regionNewsLoad(data){
    $id('divMyRegionContainer').innerHTML = data;
    $id('divMyRegionContainer').style.display = '';
}

// **************************
// Load saved user settings
// **************************

function pageLoadShowWeather(){
    if($id("weather")==null)
        return;
    
    if(!savedW)
        $("#weather").fadeIn("slow");
    
    if(!savedR)
        $id("divMyRegionContainer").style.display = '';

    if(!savedW && !savedR) 
        return;

    var wCity = eval($.cookie('Oboz/Weather'));
    var rCity = eval($.cookie('Oboz/Region'));

    if(wCity!=null && wCity!=0 && wCity!=204){
        curWCity = wCity;
        $.get(cityWSearchURL+"?cityID="+wCity,null,showUserSavedWeather);
    }
    else
        $("#weather").fadeIn("slow");
        
    if(rCity!=null && rCity!=0 && rCity!=207){
        curRCity = rCity;
        $.get(cityWSearchURL+"?mode=news&cityID="+rCity,null,showUserSavedRegion);
    }
    else
        $id("divMyRegionContainer").style.display = '';
}
function showUserSavedRegion(data){
    selectRCityName(curRCity,data);
}

function showUserSavedWeather(data) {
    selectWCityName(curWCity,data);
}

// **************************
// Save user settings
// **************************
    //-- Weather
    function saveWeather(){
        if(!eval(savedW))
            $.get(weatherURL+"?save=true&data="+curWCity,null,savedWeather);
        else
            $.get(weatherURL+"?remove=true",null,removedWeather);
    }
    function savedWeather(data){
        $id("saveWCity").innerHTML = "������������"
        savedW = true;
    }
    function removedWeather(data){
        $id("saveWCity").innerHTML = "���������"
        savedW = false;
        selectWCityName(204,'����') 
    }

    //-- Region
    function saveRegion(){
        if(!eval(savedR))
            $.get(weatherURL+"?mode=news&save=true&data="+curRCity,null,savedRegion);
        else
            $.get(weatherURL+"?mode=news&remove=true",null,removedRegion);
    }
    function savedRegion(data){
        $id("saveRCity").innerHTML = "������������"
        savedR = true;
    }
    function removedRegion(data){
        $id("saveRCity").innerHTML = "���������"
        savedR = false;
        selectRCityName(207, '����')
    }


//golosovanie
function HighlightStar(nPos)
{
     document.getElementById("Vote1").src = (nPos >= 1 ? "/_site/_pic/st_1.gif" : "/_site/_pic/st_0.gif");
     document.getElementById("Vote2").src = (nPos >= 2 ? "/_site/_pic/st_1.gif" : "/_site/_pic/st_0.gif");
     document.getElementById("Vote3").src = (nPos >= 3 ? "/_site/_pic/st_1.gif" : "/_site/_pic/st_0.gif");
     document.getElementById("Vote4").src = (nPos >= 4 ? "/_site/_pic/st_1.gif" : "/_site/_pic/st_0.gif");
     document.getElementById("Vote5").src = (nPos >= 5 ? "/_site/_pic/st_1.gif" : "/_site/_pic/st_0.gif");
}

// ����������� (��������)
var voteResultURL = '/_site/src/votingNew.aspx';
function voteShowQuestion(){
    $id('linkBack').style.display = 'none';
    $id('linkVote').style.display = '';
    tmpVoteData = tmpQuestion;
    $("#voteDivBody").slideUp("slow",voteResLoadAndDivHide);
}
var tmpQuestion;
function voteShowRes(id) {
    $id('linkBack').style.display = '';
    $id('linkVote').style.display = 'none';
    tmpQuestion = $id("voteDivBody").innerHTML;
    $.get(voteResultURL+'?_id='+id,null,voteResLoad);
    $("#voteDivBody").slideUp("slow");
}
function voteNew(id) {
    if(_voteVal == -1) {
        $id('voteError').style.display = '';
    }
    else {
        $id('linkVote').style.display = 'none';
        $id('voteError').style.display = 'none';
        $.get(voteResultURL+'?_id='+id+'&vote_for='+_voteVal,null,voteResLoad);
        $("#voteDivBody").slideUp("slow");
    }
}
var tmpVoteData;
function voteResLoad(data) {
    tmpVoteData = data
    voteResLoadAndDivHide();
}
function voteResLoadAndDivHide(){
    if ($("#voteDivBody").is(":hidden")) {
        $id("voteDivBody").innerHTML = tmpVoteData;
        $("#voteDivBody").slideDown("slow");
    }
    else {
        setTimeout("voteResLoadAndDivHide()",0);
    }
}
var _voteVal = -1;
// Select vote value
function sVV(value) { _voteVal = value }

function RandomImageLong(images,width,height)
{
 si = 0; 
 ci=0;
 cc=0;
 imageSet = new Array();
 ei = images.length;
  for (i=1;i<ei;i++) {
    if (images.charAt(i) == '$') {
      imageSet[cc] = images.substring(si,i);
      cc++;
      si=i+1;
      }
    }
  ind = Math.floor(Math.random() *cc);
  document.write("<object classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 codebase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0 width="+width+" height="+height+"><param name=bgcolor value=#ffffff /><param name=wmode value=transparent /><param name=movie value=/_site/_pic/banners1/"+imageSet[ind]+"><param name=quality value=high><embed wmode='transparent' src=/_site/_pic/banners1/"+imageSet[ind]+" quality=high pluginspage=http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash type=application/x-shockwave-flash width="+width+" height="+height+"></object>");
}

// show tabs
function ShowPhoto(){
    if($id('photoTabBody')==null || $id('videoTabBody')==null)
        return;
    
    if($id('photoTabBody').style.display == 'none'){
        $id('videoTabBody').style.display = 'none';
        $id('photoTabBody').style.display = '';
        
        $id('photoTab').className = 'tabActiveIn';
        $id('photoTab').parentNode.className = 'tabActive';
        $id('videoTab').className = 'tabPassiveIn';
        $id('videoTab').parentNode.className = 'tabPassive4';
    }
}
function ShowVideo(){
    if($id('photoTabBody')==null || $id('videoTabBody')==null)
        return;
        
    if($id('videoTabBody').style.display == 'none'){
        $id('photoTabBody').style.display = 'none';
        $id('videoTabBody').style.display = '';

        $id('videoTab').className = 'tabActiveIn';
        $id('videoTab').parentNode.className = 'tabActive';
        $id('photoTab').className = 'tabPassiveIn';
        $id('photoTab').parentNode.className = 'tabPassive4';
    }
}

function ReSize(step)
{
    document.getElementById('article').className='articleAttribute articleFontSize'+step;
    document.getElementById('tdp1').className='page3';
    document.getElementById('tdp2').className='page3';
    document.getElementById('tdp3').className='page3';

    if(step==3)  document.getElementById('tdp1').className='page3act';
    if(step==5)  document.getElementById('tdp2').className='page3act';
    if(step==10)  document.getElementById('tdp3').className='page3act';

    SaveCookie('Oboz/articleSize',step);
}



function menuOver(){
    if(eval("$id('m"+curMenu+"')")!=null) eval("$id('m"+curMenu+"').style.backgroundColor=''")
    holdMenu = true;
}

function menuOut(){
    holdMenu = false;
}

function menuColor(){
    if(holdMenu){setTimeout('menuColor()',1000);return;}
    
    var nextMenu = eval(curMenu)+1;
    if(nextMenu>13)nextMenu=1;
    if(eval("$id('m"+nextMenu+"').className")=="mainMenuItemPassive") nextMenu++;
    if(nextMenu>13)nextMenu=1;

    if(eval("$id('m"+curMenu+"')")!=null) eval("$id('m"+curMenu+"').style.backgroundColor=''")
    eval("$id('m"+nextMenu+"').style.backgroundColor='#0087ae'")
    
    curMenu = nextMenu;
    setTimeout('menuColor()',1000)
}

            function selectCity(){
                $id('dnWeatherDiv').style.display = 'none';
                $id('upWeatherDiv').style.display = '';
            }
            function selectCity2(){
                $id('upWeatherDiv').style.display = 'none';
                $id('dnWeatherDiv').style.display = '';
            }
            function selectCityWeather(id){
                $.get('/_site/src/inc/weatherHeader.ashx?id='+id,null,showCityWeather)
            }
            function showCityWeather(data){
                var arr = data.split('|||');
                $id('wCityImg').src = arr[0];
                $id('wCityName').innerHTML = arr[2];
                $id('wCityData').innerHTML = arr[1];
                $id('wCityImgTom').src = arr[3];
                $id('wCityDataTom').innerHTML = arr[4];
                selectCity2();
            }

function setAsHome(myLink)
{
    if(document.all) {
           // IE
           myLink.style.behavior='url(#default#homepage)';
           myLink.setHomePage(location.href);
    } else {
        document.getElementById("showToolTip").style.display = "";
        setTimeout("hideShowSetHome()",4000);
    }
}
function hideShowSetHome(){
    document.getElementById("showToolTip").style.display = "none";
}

function LogSearch(query)
{
    var url= 'http://obozrevatel.com/_site/src/log/Log.aspx';
    var handler = null;
    var status = false;
    var contentType = "application/x-www-form-urlencoded; charset=UTF-8";

    // Native XMLHttpRequest object
    if (window.XMLHttpRequest) {
        request = new XMLHttpRequest();
        //request.onreadystatechange = handler;
        request.open("get", url, true);
        request.setRequestHeader("Content-Type", contentType);
        request.send(query);
        status = true;

    // ActiveX XMLHttpRequest object
    } else if (window.ActiveXObject) {
        request = new ActiveXObject("Microsoft.XMLHTTP");
        if (request) {
            //request.onreadystatechange = handler;
            request.open("get", url, true);
            request.setRequestHeader("Content-Type", contentType);
            request.send(query);
            status = true;
        }
    }

    return status;
}

function DoSearch()
{
    //LogSearch('?k=' + document.getElementById('k').value+"&u="+window.location+"&t=web");
    location.href="http://www.obozrevatel.com/_site/src/search_result.aspx?k="+encodeURI(document.getElementById('k').value)
}

function searchInWorld()
{
    try     {    DoLog();}catch(err){}
    location.href="http://search.oboz.ua/search.aspx?k="+encodeURI(document.getElementById('k').value)+"&type=Web"
}

function bookmarksite(title,url)
{
    if (window.sidebar) // firefox
        window.sidebar.addPanel(title, url, "");
    else if(window.opera && window.print){ // opera
        var elem = document.createElement('a');
        elem.setAttribute('href',url);
        elem.setAttribute('title',title);
        elem.setAttribute('rel','sidebar');
        elem.click();
    }
    else if(document.all)// ie
        window.external.AddFavorite(url, title);
}

function tabInit(){
    var pageSections = document.location.href.split('#');
    if (pageSections.length == 1)
        return;

    var tab = pageSections[1];

    if (tab.indexOf("vd") == 0) {
        ShowVideo();
    }
    else if (tab.indexOf("photo") == 0) {
        ShowPhoto();
    }
    
}